#!/bin/bash
for i in 8.3 8.4 8.5 8.6 8.7 8.8 8.9
do
for j in 1.60 1.61 1.62 1.63 1.64 1.65
do
	awk '{gsub(/X/,'$i')}1' postemp > postemp2
	awk '{gsub(/Z/,'$j')}1' postemp2 > GaNwurtzite.in
	mpirun -np 1 pw.x  -nk 1 -nd 1 -nb 1 -nt 1 < GaNwurtzite.in > a${i}c${j}.out
done
done
