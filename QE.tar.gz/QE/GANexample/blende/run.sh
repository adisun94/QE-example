#!/bin/bash
for i in 8.3 8.4 8.5 8.6 8.7 8.8 8.9
do
	awk '{gsub(/X/,'$i')}1' postemp > GaNblende.in
	mpirun -np 1 pw.x  -nk 1 -nd 1 -nb 1 -nt 1 < GaNblende.in > a${i}.out
done
